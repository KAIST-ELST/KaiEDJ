using Distributed

@everywhere using Pkg
@everywhere project_path_ed = ENV["PROJECT_PATH_ED"]
@everywhere Pkg.activate(project_path_ed)

@everywhere using Formatting
@everywhere using LinearAlgebra
@everywhere using SparseArrays
@everywhere using DelimitedFiles
@everywhere using FastGaussQuadrature
@everywhere using BenchmarkTools
@everywhere using Optimization
@everywhere using OptimizationOptimJL
@everywhere using Optim
@everywhere using TickTock
@everywhere using HDF5
@everywhere using TOML
@everywhere using JLD2

@everywhere module MyBase
include("basic.jl")
include("printout.jl")
include("binary_basis.jl")
include("wavefunction.jl")
include("operators.jl")
include("operators_phys.jl")
include("hamiltonian.jl")
include("green.jl")
include("bethe.jl")
include("discretization.jl")
include("lib_continued_fraction.jl")
include("tb_lattice.jl")
include("ed_solver.jl")
include("observables.jl")
end
@everywhere using Main.MyBase
