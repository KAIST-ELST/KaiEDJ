
function ContinuedFrac()
end

mutable struct CFracCoeff
end
